import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Wallet, Globe, Blocks } from "lucide-react";
import { SiX, SiGithub, SiDiscord, SiTelegram, SiYoutube, SiMedium, SiLinkedin } from "react-icons/si";
import { useAddressFormat } from "@/contexts/address-format-context";
import { Link } from "wouter";

interface SocialLink {
  icon: string;
  url: string;
  label: string;
}

interface SettingsData {
  social?: Record<string, string>;
  branding?: Record<string, string>;
  network?: Record<string, string>;
  chain?: {
    chainId: number;
    name: string;
    shortName: string;
    rpcUrl: string;
    nativeCurrency: string;
    nativeSymbol: string;
    nativeDecimals: number;
  };
}

const SOCIAL_ICONS: Record<string, any> = {
  website: Globe,
  twitter: SiX,
  github: SiGithub,
  discord: SiDiscord,
  telegram: SiTelegram,
  youtube: SiYoutube,
  medium: SiMedium,
  linkedin: SiLinkedin,
};

export function Footer() {
  const { toast } = useToast();
  const [isAdding, setIsAdding] = useState(false);
  const { addressFormat } = useAddressFormat();
  
  const { data: settings } = useQuery<SettingsData>({
    queryKey: ["/api/settings"],
    staleTime: 60000,
  });

  const chain = settings?.chain;
  const chainId = chain?.chainId || 55369;
  const chainName = chain?.name || "Team369";
  const nativeSymbol = chain?.nativeSymbol || "T369";
  const nativeCurrency = chain?.nativeCurrency || "Team369";
  const nativeDecimals = chain?.nativeDecimals || 18;
  const rpcUrl = chain?.rpcUrl || settings?.network?.rpc_url || "https://rpc.t369coin.org";
  
  const displayChainId = addressFormat === "bech32" ? `team369_${chainId}-1` : String(chainId);

  const socialLinks: SocialLink[] = (() => {
    try {
      const linksStr = settings?.social?.social_links;
      if (linksStr) {
        return JSON.parse(linksStr);
      }
    } catch {}
    return [
      { icon: "website", url: "https://t369coin.org", label: "Website" },
      { icon: "twitter", url: "https://twitter.com/team369", label: "Twitter" },
    ];
  })();

  const siteName = settings?.branding?.site_name || "Team369 Explorer";
  const siteDescription = settings?.branding?.site_description || 
    `Blockchain Explorer for ${chainName}. Track transactions, explore blocks, and interact with smart contracts.`;

  const addToWallet = async () => {
    if (typeof window === "undefined" || !(window as any).ethereum) {
      toast({
        title: "Wallet not found",
        description: "Please install MetaMask or another Web3 wallet.",
        variant: "destructive",
      });
      return;
    }

    setIsAdding(true);
    try {
      const chainConfig = {
        chainId: `0x${chainId.toString(16)}`,
        chainName: chainName,
        nativeCurrency: {
          name: nativeCurrency,
          symbol: nativeSymbol,
          decimals: nativeDecimals,
        },
        rpcUrls: [rpcUrl.startsWith("http") ? rpcUrl : `https://${rpcUrl}`],
        blockExplorerUrls: [window.location.origin],
      };
      await (window as any).ethereum.request({
        method: "wallet_addEthereumChain",
        params: [chainConfig],
      });
      toast({
        title: "Network added",
        description: `${chainName} has been added to your wallet.`,
      });
    } catch (err: any) {
      if (err.code === 4001) {
        toast({
          title: "Request cancelled",
          description: "You cancelled the request to add the network.",
        });
      } else {
        toast({
          title: "Failed to add network",
          description: err.message || "Please add the network manually.",
          variant: "destructive",
        });
      }
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <footer className="border-t bg-muted/30 mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Blocks className="h-6 w-6 text-primary" />
              <span className="font-semibold text-lg">{siteName}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {siteDescription}
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold">Network Info</h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center justify-between gap-4">
                <span>Chain ID:</span>
                <span className="font-mono">{displayChainId}</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span>Currency:</span>
                <span className="font-mono">{nativeSymbol}</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span>RPC:</span>
                <span className="font-mono text-xs truncate max-w-[150px]">{rpcUrl.replace(/^https?:\/\//, "")}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold">Quick Actions</h3>
            <Button
              onClick={addToWallet}
              disabled={isAdding}
              className="w-full"
              data-testid="button-add-to-wallet"
            >
              <Wallet className="h-4 w-4 mr-2" />
              {isAdding ? "Adding..." : `Add ${chainName} to Wallet`}
            </Button>
            <div className="flex items-center gap-2 flex-wrap">
              {socialLinks.map((link, index) => {
                const IconComponent = SOCIAL_ICONS[link.icon] || Globe;
                return (
                  <Button key={index} variant="outline" size="icon" asChild>
                    <a 
                      href={link.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      data-testid={`link-social-${link.icon}`}
                      title={link.label}
                    >
                      <IconComponent className="h-4 w-4" />
                    </a>
                  </Button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} {chainName}. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="/terms" className="hover:text-foreground transition-colors" data-testid="link-terms">Terms</Link>
            <Link href="/privacy" className="hover:text-foreground transition-colors" data-testid="link-privacy">Privacy</Link>
            <Link href="/api-docs" className="hover:text-foreground transition-colors" data-testid="link-api">API</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
