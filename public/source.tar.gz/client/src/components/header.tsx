import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Blocks, ArrowRightLeft, Users, LayoutDashboard, Menu, LogIn, LogOut, Coins, TrendingUp, BookOpen, Gift, Code, Key, CreditCard, ChevronDown } from "lucide-react";
import { ChainSelector } from "./chain-selector";
import { GasTracker } from "./gas-tracker";
import { AddressFormatToggle } from "./address-format-toggle";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/blocks", label: "Blocks", icon: Blocks },
  { href: "/txs", label: "Transactions", icon: ArrowRightLeft },
  { href: "/tokens", label: "Tokens", icon: Coins },
  { href: "/airdrops", label: "Airdrops", icon: Gift },
  { href: "/analytics", label: "Analytics", icon: TrendingUp },
  { href: "/accounts", label: "Accounts", icon: Users },
  { href: "/api-docs", label: "Docs", icon: BookOpen },
];

interface User {
  id: number;
  username: string;
  email: string;
}

export function Header() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: user, isLoading: isAuthLoading } = useQuery<User>({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/auth/logout");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Logged out",
        description: "You have been logged out successfully.",
      });
      setLocation("/");
    },
  });

  const isLoggedIn = !!user && !isAuthLoading;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-14 items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2" data-testid="link-home">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
                <Blocks className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-semibold text-lg">
                <span className="sm:hidden">Telebit</span>
                <span className="hidden sm:inline">Telebit Explorer</span>
              </span>
            </Link>
            <ChainSelector className="hidden sm:flex" />
            <AddressFormatToggle />
            <div className="hidden lg:flex items-center px-2 py-1 rounded-md bg-muted/50">
              <GasTracker />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = location === item.href || 
                  (item.href !== "/" && location.startsWith(item.href));
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      size="sm"
                      className="gap-2"
                      data-testid={`nav-${item.label.toLowerCase()}`}
                    >
                      <item.icon className="h-4 w-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </nav>

            {isLoggedIn ? (
              <>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="hidden md:flex gap-2"
                      data-testid="button-developer-menu"
                    >
                      <Code className="h-4 w-4" />
                      Developer
                      <ChevronDown className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <Link href="/developer/api-keys">
                      <DropdownMenuItem className="gap-2 cursor-pointer" data-testid="menu-api-keys">
                        <Key className="h-4 w-4" />
                        API Keys
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/developer/plans">
                      <DropdownMenuItem className="gap-2 cursor-pointer" data-testid="menu-api-plans">
                        <CreditCard className="h-4 w-4" />
                        API Plans
                      </DropdownMenuItem>
                    </Link>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="gap-2 cursor-pointer text-destructive"
                      onClick={() => logoutMutation.mutate()}
                      data-testid="menu-logout"
                    >
                      <LogOut className="h-4 w-4" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Button
                  variant="outline"
                  size="icon"
                  className="md:hidden"
                  onClick={() => logoutMutation.mutate()}
                  data-testid="button-logout-mobile"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button
                    variant="default"
                    size="sm"
                    className="hidden md:flex gap-2"
                    data-testid="button-login"
                  >
                    <LogIn className="h-4 w-4" />
                    Login
                  </Button>
                </Link>

                <Link href="/login">
                  <Button
                    variant="default"
                    size="icon"
                    className="md:hidden"
                    data-testid="button-login-mobile"
                  >
                    <LogIn className="h-4 w-4" />
                  </Button>
                </Link>
              </>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden"
                  data-testid="button-mobile-menu"
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {navItems.map((item) => {
                  const isActive = location === item.href ||
                    (item.href !== "/" && location.startsWith(item.href));
                  return (
                    <Link key={item.href} href={item.href}>
                      <DropdownMenuItem 
                        className={`gap-2 cursor-pointer ${isActive ? "bg-secondary" : ""}`}
                        data-testid={`mobile-nav-${item.label.toLowerCase()}`}
                      >
                        <item.icon className="h-4 w-4" />
                        {item.label}
                      </DropdownMenuItem>
                    </Link>
                  );
                })}
                {isLoggedIn && (
                  <>
                    <DropdownMenuSeparator />
                    <Link href="/developer/api-keys">
                      <DropdownMenuItem className="gap-2 cursor-pointer" data-testid="mobile-nav-api-keys">
                        <Key className="h-4 w-4" />
                        API Keys
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/developer/plans">
                      <DropdownMenuItem className="gap-2 cursor-pointer" data-testid="mobile-nav-api-plans">
                        <CreditCard className="h-4 w-4" />
                        API Plans
                      </DropdownMenuItem>
                    </Link>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}
