import { useEffect, lazy, Suspense } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AddressFormatProvider } from "@/contexts/address-format-context";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Skeleton } from "@/components/ui/skeleton";

import Dashboard from "@/pages/dashboard";
import BlocksPage from "@/pages/blocks";
import BlockDetail from "@/pages/block-detail";
import TransactionsPage from "@/pages/transactions";
import TransactionDetail from "@/pages/transaction-detail";
import AddressPage from "@/pages/address";
import NotFound from "@/pages/not-found";

const AccountsPage = lazy(() => import("@/pages/accounts"));
const SearchPage = lazy(() => import("@/pages/search"));
const LoginPage = lazy(() => import("@/pages/login"));
const TokensPage = lazy(() => import("@/pages/tokens"));
const TokenPage = lazy(() => import("@/pages/token"));
const AnalyticsPage = lazy(() => import("@/pages/analytics"));
const ApiDocsPage = lazy(() => import("@/pages/api-docs"));
const WatchlistPage = lazy(() => import("@/pages/watchlist"));
const AirdropsPage = lazy(() => import("@/pages/airdrops"));
const AirdropDetailPage = lazy(() => import("@/pages/airdrop-detail"));
const ApiKeysPage = lazy(() => import("@/pages/developer/api-keys"));
const ApiPlansPage = lazy(() => import("@/pages/developer/plans"));
const AdminLoginPage = lazy(() => import("@/pages/admin/login"));
const AdminDashboardPage = lazy(() => import("@/pages/admin/dashboard"));
const TermsPage = lazy(() => import("@/pages/terms"));
const PrivacyPage = lazy(() => import("@/pages/privacy"));

function PageLoader() {
  return (
    <div className="container mx-auto p-6 space-y-4">
      <Skeleton className="h-8 w-48" />
      <Skeleton className="h-32 w-full" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

function ScrollToTop() {
  const [location] = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  
  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/blocks" component={BlocksPage} />
      <Route path="/block/:id" component={BlockDetail} />
      <Route path="/txs" component={TransactionsPage} />
      <Route path="/tx/:hash" component={TransactionDetail} />
      <Route path="/address/:address" component={AddressPage} />
      <Route path="/accounts" component={AccountsPage} />
      <Route path="/tokens" component={TokensPage} />
      <Route path="/token/:address" component={TokenPage} />
      <Route path="/analytics" component={AnalyticsPage} />
      <Route path="/api-docs" component={ApiDocsPage} />
      <Route path="/watchlist" component={WatchlistPage} />
      <Route path="/airdrops" component={AirdropsPage} />
      <Route path="/airdrop/:id" component={AirdropDetailPage} />
      <Route path="/search" component={SearchPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/developer/api-keys" component={ApiKeysPage} />
      <Route path="/developer/plans" component={ApiPlansPage} />
      <Route path="/admin" component={AdminLoginPage} />
      <Route path="/admin/login" component={AdminLoginPage} />
      <Route path="/admin/dashboard" component={AdminDashboardPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AddressFormatProvider>
        <TooltipProvider>
          <div className="min-h-screen bg-background">
            <ScrollToTop />
            <Header />
            <main>
              <Suspense fallback={<PageLoader />}>
                <Router />
              </Suspense>
            </main>
            <Footer />
          </div>
          <Toaster />
        </TooltipProvider>
      </AddressFormatProvider>
    </QueryClientProvider>
  );
}

export default App;
