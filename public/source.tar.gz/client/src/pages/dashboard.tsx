import { useQuery } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import { StatsCard } from "@/components/stats-card";
import { BlocksTable } from "@/components/blocks-table";
import { TransactionsTable } from "@/components/transactions-table";
import { SearchBar } from "@/components/search-bar";
import { Card, CardContent } from "@/components/ui/card";
import { Blocks, ArrowRightLeft, Users, Fuel } from "lucide-react";
import { formatNumber, formatGwei } from "@/lib/formatters";
import type { Block, Transaction, NetworkStats } from "@shared/schema";

interface BootstrapData {
  stats: NetworkStats;
  blocks: Block[];
  transactions: Transaction[];
  settings: {
    branding?: {
      site_name?: string;
      site_description?: string;
    };
  };
}

export default function Dashboard() {
  const [showStickySearch, setShowStickySearch] = useState(false);
  const searchCardRef = useRef<HTMLDivElement>(null);

  // Single API call for all initial data
  const { data: bootstrap, isLoading } = useQuery<BootstrapData>({
    queryKey: ["/api/bootstrap"],
    staleTime: 3000,
    refetchInterval: 15000,
  });

  const stats = bootstrap?.stats;
  const blocksData = bootstrap?.blocks;
  const txsData = bootstrap?.transactions;
  const settings = bootstrap?.settings;

  const siteName = settings?.branding?.site_name || "Telebit Blockchain Explorer";
  const siteDescription = settings?.branding?.site_description || "Explore blocks, transactions, and accounts on the Telebit network";

  useEffect(() => {
    const handleScroll = () => {
      if (searchCardRef.current) {
        const rect = searchCardRef.current.getBoundingClientRect();
        const headerHeight = 56;
        setShowStickySearch(rect.bottom < headerHeight);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="lg:flex lg:flex-row lg:items-center lg:justify-between lg:gap-4">
        <div className="mb-4 lg:mb-0">
          <h1 className="text-2xl font-semibold" data-testid="text-page-title">
            {siteName}
          </h1>
          <p className="text-muted-foreground mt-1">
            {siteDescription}
          </p>
        </div>
        <div ref={searchCardRef} className="lg:flex-1 lg:max-w-2xl">
          <Card>
            <CardContent className="p-3">
              <SearchBar />
            </CardContent>
          </Card>
        </div>
      </div>
      
      {showStickySearch && (
        <div 
          className="fixed top-[55px] left-0 right-0 z-40 bg-background border-b lg:hidden animate-in slide-in-from-top duration-200"
        >
          <div className="px-4 py-1.5">
            <SearchBar />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Latest Block"
          value={stats?.latestBlock ? formatNumber(stats.latestBlock) : "0"}
          icon={Blocks}
          isLoading={isLoading}
        />
        <StatsCard
          title="Total Transactions"
          value={stats?.totalTransactions ? formatNumber(stats.totalTransactions) : "0"}
          icon={ArrowRightLeft}
          isLoading={isLoading}
        />
        <StatsCard
          title="Total Addresses"
          value={stats?.totalAddresses ? formatNumber(stats.totalAddresses) : "0"}
          icon={Users}
          isLoading={isLoading}
        />
        <StatsCard
          title="Avg Gas Price"
          value={stats?.avgGasPrice ? `${formatGwei(stats.avgGasPrice)} Gwei` : "0 Gwei"}
          icon={Fuel}
          isLoading={isLoading}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <BlocksTable
          blocks={blocksData || []}
          isLoading={isLoading}
          showViewAll
          limit={8}
        />
        <TransactionsTable
          transactions={txsData || []}
          isLoading={isLoading}
          showViewAll
          limit={8}
        />
      </div>
    </div>
  );
}
